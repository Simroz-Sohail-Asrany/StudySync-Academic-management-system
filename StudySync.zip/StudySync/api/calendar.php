<?php
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$user = requireAuth();
$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch ($method) {
    case 'GET':
        $month = $_GET['month'] ?? date('m');
        $year = $_GET['year'] ?? date('Y');

        try {
            $startDate = "$year-$month-01";
            $endDate = date('Y-m-t', strtotime($startDate));

            // Get events
            $stmt = $db->prepare("
                SELECT * FROM events 
                WHERE user_id = ? AND event_date BETWEEN ? AND ?
                ORDER BY event_date, start_time
            ");
            $stmt->execute([$user['user_id'], $startDate, $endDate]);
            $events = $stmt->fetchAll();

            // Get assignments as events
            $stmt = $db->prepare("
                SELECT a.*, c.course_name, c.course_code, 'deadline' as event_type, '#ef4444' as color
                FROM assignments a
                JOIN courses c ON a.course_id = c.course_id
                JOIN enrollments e ON c.course_id = e.course_id
                WHERE e.student_id = ? AND DATE(a.due_date) BETWEEN ? AND ?
            ");
            $stmt->execute([$user['user_id'], $startDate, $endDate]);
            $assignments = $stmt->fetchAll();

            // Get class schedules
            $stmt = $db->prepare("
                SELECT cs.*, c.course_name, c.course_code, 'class' as event_type, '#6366f1' as color
                FROM class_schedules cs
                JOIN courses c ON cs.course_id = c.course_id
                JOIN enrollments e ON c.course_id = e.course_id
                WHERE e.student_id = ?
            ");
            $stmt->execute([$user['user_id']]);
            $schedules = $stmt->fetchAll();

            echo json_encode([
                'success' => true,
                'events' => $events,
                'assignments' => $assignments,
                'schedules' => $schedules
            ]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'POST':
        try {
            $stmt = $db->prepare("
                INSERT INTO events (user_id, title, description, event_date, start_time, end_time, event_type, color, is_all_day)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $user['user_id'],
                $input['title'],
                $input['description'] ?? '',
                $input['event_date'],
                $input['start_time'] ?? null,
                $input['end_time'] ?? null,
                $input['event_type'] ?? 'personal',
                $input['color'] ?? '#6366f1',
                $input['is_all_day'] ?? false
            ]);

            echo json_encode(['success' => true, 'event_id' => $db->lastInsertId()]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'DELETE':
        $eventId = $_GET['id'] ?? null;
        if ($eventId) {
            $stmt = $db->prepare("DELETE FROM events WHERE event_id = ? AND user_id = ?");
            $stmt->execute([$eventId, $user['user_id']]);
            echo json_encode(['success' => true]);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>