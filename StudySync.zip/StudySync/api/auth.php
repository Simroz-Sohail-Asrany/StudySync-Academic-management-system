<?php
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);
$auth = new Auth();

switch ($method) {
    case 'POST':
        $action = $input['action'] ?? $_POST['action'] ?? '';

        switch ($action) {
            case 'login':
                $email = $input['email'] ?? $_POST['email'] ?? '';
                $password = $input['password'] ?? $_POST['password'] ?? '';

                if (empty($email) || empty($password)) {
                    echo json_encode(['success' => false, 'message' => 'Email and password required']);
                    exit;
                }

                $result = $auth->login($email, $password);
                echo json_encode($result);
                break;

            case 'register':
                $email = $input['email'] ?? $_POST['email'] ?? '';
                $password = $input['password'] ?? $_POST['password'] ?? '';
                $fullName = $input['full_name'] ?? $_POST['full_name'] ?? '';
                $department = $input['department'] ?? $_POST['department'] ?? '';

                if (empty($email) || empty($password) || empty($fullName)) {
                    echo json_encode(['success' => false, 'message' => 'All fields are required']);
                    exit;
                }

                if (strlen($password) < 6) {
                    echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters']);
                    exit;
                }

                $result = $auth->register($email, $password, $fullName, $department);
                echo json_encode($result);
                break;

            case 'logout':
                $user = requireAuth();
                $result = $auth->logout($user['user_id']);
                echo json_encode($result);
                break;

            default:
                echo json_encode(['success' => false, 'message' => 'Invalid action']);
        }
        break;

    case 'GET':
        $user = $auth->getCurrentUser();
        if ($user) {
            echo json_encode(['success' => true, 'user' => $user]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Not authenticated']);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>