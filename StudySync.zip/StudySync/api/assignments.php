<?php
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$user = requireAuth();
$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch ($method) {
    case 'GET':
        $courseId = $_GET['course_id'] ?? null;
        $status = $_GET['status'] ?? 'all';

        try {
            if ($courseId) {
                $stmt = $db->prepare("
                    SELECT a.*, c.course_name, c.course_code,
                    (SELECT COUNT(*) FROM assignment_submissions WHERE assignment_id = a.assignment_id AND student_id = ?) as submitted
                    FROM assignments a 
                    JOIN courses c ON a.course_id = c.course_id 
                    WHERE a.course_id = ? 
                    ORDER BY a.due_date ASC
                ");
                $stmt->execute([$user['user_id'], $courseId]);
            } else {
                $sql = "
                    SELECT a.*, c.course_name, c.course_code,
                    (SELECT COUNT(*) FROM assignment_submissions WHERE assignment_id = a.assignment_id AND student_id = ?) as submitted
                    FROM assignments a 
                    JOIN courses c ON a.course_id = c.course_id 
                    JOIN enrollments e ON c.course_id = e.course_id 
                    WHERE e.student_id = ?
                ";
                if ($status === 'upcoming') {
                    $sql .= " AND a.due_date >= NOW()";
                } elseif ($status === 'overdue') {
                    $sql .= " AND a.due_date < NOW()";
                }
                $sql .= " ORDER BY a.due_date ASC";

                $stmt = $db->prepare($sql);
                $stmt->execute([$user['user_id'], $user['user_id']]);
            }

            echo json_encode(['success' => true, 'assignments' => $stmt->fetchAll()]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'POST':
        requireRole(['instructor', 'admin']);

        try {
            $stmt = $db->prepare("
                INSERT INTO assignments (course_id, title, description, due_date, priority, assignment_type, max_marks, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $input['course_id'],
                $input['title'],
                $input['description'],
                $input['due_date'],
                $input['priority'] ?? 'medium',
                $input['assignment_type'] ?? 'individual',
                $input['max_marks'] ?? 100,
                $user['user_id']
            ]);

            echo json_encode(['success' => true, 'assignment_id' => $db->lastInsertId()]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>