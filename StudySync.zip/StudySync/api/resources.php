<?php
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$user = requireAuth();
$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch ($method) {
    case 'GET':
        $search = $_GET['search'] ?? '';
        $courseId = $_GET['course_id'] ?? null;
        $type = $_GET['type'] ?? null;

        try {
            $sql = "
                SELECT r.*, u.full_name as uploader_name, c.course_name,
                (SELECT AVG(rating) FROM resource_ratings WHERE resource_id = r.resource_id) as avg_rating,
                (SELECT COUNT(*) FROM resource_ratings WHERE resource_id = r.resource_id) as rating_count
                FROM resources r
                JOIN users u ON r.uploaded_by = u.user_id
                LEFT JOIN courses c ON r.course_id = c.course_id
                WHERE r.status = 'approved'
            ";
            $params = [];

            if ($search) {
                $sql .= " AND (r.title LIKE ? OR r.description LIKE ? OR r.tags LIKE ?)";
                $searchTerm = "%$search%";
                $params = [$searchTerm, $searchTerm, $searchTerm];
            }

            if ($courseId) {
                $sql .= " AND r.course_id = ?";
                $params[] = $courseId;
            }

            if ($type) {
                $sql .= " AND r.resource_type = ?";
                $params[] = $type;
            }

            $sql .= " ORDER BY r.created_at DESC";

            $stmt = $db->prepare($sql);
            $stmt->execute($params);

            echo json_encode(['success' => true, 'resources' => $stmt->fetchAll()]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'POST':
        $action = $input['action'] ?? '';

        try {
            switch ($action) {
                case 'upload':
                    $stmt = $db->prepare("
                        INSERT INTO resources (title, description, course_id, uploaded_by, resource_type, tags, file_url, file_type, file_size, status)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $input['title'],
                        $input['description'] ?? '',
                        $input['course_id'] ?? null,
                        $user['user_id'],
                        $input['resource_type'] ?? 'other',
                        $input['tags'] ?? '',
                        $input['file_url'] ?? '',
                        $input['file_type'] ?? '',
                        $input['file_size'] ?? 0,
                        $user['role'] === 'instructor' || $user['role'] === 'admin' ? 'approved' : 'pending'
                    ]);
                    echo json_encode(['success' => true, 'resource_id' => $db->lastInsertId()]);
                    break;

                case 'bookmark':
                    $stmt = $db->prepare("INSERT INTO resource_bookmarks (user_id, resource_id) VALUES (?, ?)");
                    $stmt->execute([$user['user_id'], $input['resource_id']]);
                    echo json_encode(['success' => true]);
                    break;

                case 'rate':
                    $stmt = $db->prepare("
                        INSERT INTO resource_ratings (resource_id, user_id, rating, review)
                        VALUES (?, ?, ?, ?)
                        ON DUPLICATE KEY UPDATE rating = ?, review = ?
                    ");
                    $stmt->execute([
                        $input['resource_id'], $user['user_id'], $input['rating'], $input['review'] ?? '',
                        $input['rating'], $input['review'] ?? ''
                    ]);
                    echo json_encode(['success' => true]);
                    break;

                case 'verify':
                    requireRole(['instructor', 'admin']);
                    $stmt = $db->prepare("
                        UPDATE resources SET is_verified = 1, verified_by = ?, verified_at = NOW(), status = 'approved'
                        WHERE resource_id = ?
                    ");
                    $stmt->execute([$user['user_id'], $input['resource_id']]);
                    echo json_encode(['success' => true]);
                    break;

                default:
                    echo json_encode(['success' => false, 'message' => 'Invalid action']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>