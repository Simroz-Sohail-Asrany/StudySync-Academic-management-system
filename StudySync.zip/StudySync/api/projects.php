<?php
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$user = requireAuth();
$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch ($method) {
    case 'GET':
        $groupId = $_GET['group_id'] ?? null;

        try {
            if ($groupId) {
                // Get group details with members and tasks
                $stmt = $db->prepare("
                    SELECT pg.*, c.course_name, u.full_name as leader_name
                    FROM project_groups pg
                    LEFT JOIN courses c ON pg.course_id = c.course_id
                    JOIN users u ON pg.leader_id = u.user_id
                    WHERE pg.group_id = ?
                ");
                $stmt->execute([$groupId]);
                $group = $stmt->fetch();

                if (!$group) {
                    echo json_encode(['success' => false, 'message' => 'Group not found']);
                    exit;
                }

                // Get members
                $stmt = $db->prepare("
                    SELECT gm.*, u.full_name, u.email, u.profile_picture
                    FROM group_members gm
                    JOIN users u ON gm.user_id = u.user_id
                    WHERE gm.group_id = ?
                ");
                $stmt->execute([$groupId]);
                $members = $stmt->fetchAll();

                // Get tasks
                $stmt = $db->prepare("
                    SELECT pt.*, u.full_name as assigned_to_name
                    FROM project_tasks pt
                    LEFT JOIN users u ON pt.assigned_to = u.user_id
                    WHERE pt.group_id = ?
                    ORDER BY pt.created_at DESC
                ");
                $stmt->execute([$groupId]);
                $tasks = $stmt->fetchAll();

                // Get discussions
                $stmt = $db->prepare("
                    SELECT gd.*, u.full_name, u.profile_picture
                    FROM group_discussions gd
                    JOIN users u ON gd.user_id = u.user_id
                    WHERE gd.group_id = ? AND gd.parent_id IS NULL
                    ORDER BY gd.created_at DESC
                ");
                $stmt->execute([$groupId]);
                $discussions = $stmt->fetchAll();

                // Get files
                $stmt = $db->prepare("
                    SELECT gf.*, u.full_name as uploader_name
                    FROM group_files gf
                    JOIN users u ON gf.uploaded_by = u.user_id
                    WHERE gf.group_id = ?
                    ORDER BY gf.uploaded_at DESC
                ");
                $stmt->execute([$groupId]);
                $files = $stmt->fetchAll();

                echo json_encode([
                    'success' => true,
                    'group' => $group,
                    'members' => $members,
                    'tasks' => $tasks,
                    'discussions' => $discussions,
                    'files' => $files
                ]);
            } else {
                // Get all user's groups
                $stmt = $db->prepare("
                    SELECT pg.*, c.course_name,
                    (SELECT COUNT(*) FROM group_members WHERE group_id = pg.group_id) as member_count,
                    (SELECT COUNT(*) FROM project_tasks WHERE group_id = pg.group_id AND status != 'done') as pending_tasks
                    FROM project_groups pg
                    LEFT JOIN courses c ON pg.course_id = c.course_id
                    JOIN group_members gm ON pg.group_id = gm.group_id
                    WHERE gm.user_id = ?
                    ORDER BY pg.created_at DESC
                ");
                $stmt->execute([$user['user_id']]);
                echo json_encode(['success' => true, 'groups' => $stmt->fetchAll()]);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'POST':
        $action = $input['action'] ?? '';

        try {
            switch ($action) {
                case 'create_group':
                    $stmt = $db->prepare("
                        INSERT INTO project_groups (group_name, course_id, description, leader_id, project_deadline)
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $input['group_name'],
                        $input['course_id'] ?? null,
                        $input['description'] ?? '',
                        $user['user_id'],
                        $input['project_deadline'] ?? null
                    ]);
                    $groupId = $db->lastInsertId();

                    // Add creator as leader
                    $stmt = $db->prepare("INSERT INTO group_members (group_id, user_id, role_in_group) VALUES (?, ?, 'leader')");
                    $stmt->execute([$groupId, $user['user_id']]);

                    echo json_encode(['success' => true, 'group_id' => $groupId]);
                    break;

                case 'add_task':
                    $stmt = $db->prepare("
                        INSERT INTO project_tasks (group_id, title, description, assigned_to, created_by, priority, due_date)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $input['group_id'],
                        $input['title'],
                        $input['description'] ?? '',
                        $input['assigned_to'] ?? null,
                        $user['user_id'],
                        $input['priority'] ?? 'medium',
                        $input['due_date'] ?? null
                    ]);
                    echo json_encode(['success' => true, 'task_id' => $db->lastInsertId()]);
                    break;

                case 'add_member':
                    $stmt = $db->prepare("INSERT INTO group_members (group_id, user_id) VALUES (?, ?)");
                    $stmt->execute([$input['group_id'], $input['user_id']]);
                    echo json_encode(['success' => true]);
                    break;

                case 'add_discussion':
                    $stmt = $db->prepare("
                        INSERT INTO group_discussions (group_id, user_id, message, parent_id)
                        VALUES (?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $input['group_id'],
                        $user['user_id'],
                        $input['message'],
                        $input['parent_id'] ?? null
                    ]);
                    echo json_encode(['success' => true, 'discussion_id' => $db->lastInsertId()]);
                    break;

                case 'update_task_status':
                    $completedAt = $input['status'] === 'done' ? date('Y-m-d H:i:s') : null;
                    $stmt = $db->prepare("
                        UPDATE project_tasks SET status = ?, completed_at = ? WHERE task_id = ? AND group_id = ?
                    ");
                    $stmt->execute([$input['status'], $completedAt, $input['task_id'], $input['group_id']]);
                    echo json_encode(['success' => true]);
                    break;

                default:
                    echo json_encode(['success' => false, 'message' => 'Invalid action']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>