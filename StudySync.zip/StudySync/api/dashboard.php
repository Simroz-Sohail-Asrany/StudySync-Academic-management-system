<?php
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Authorization');

$user = requireAuth();
$db = getDB();

// Get counts and recent data for dashboard
$response = ['success' => true, 'data' => []];

try {
    // Upcoming deadlines (next 7 days)
    $stmt = $db->prepare("
        SELECT a.*, c.course_name, c.course_code 
        FROM assignments a 
        JOIN courses c ON a.course_id = c.course_id 
        JOIN enrollments e ON c.course_id = e.course_id 
        WHERE e.student_id = ? AND a.due_date >= NOW() 
        ORDER BY a.due_date ASC LIMIT 5
    ");
    $stmt->execute([$user['user_id']]);
    $response['data']['upcoming_deadlines'] = $stmt->fetchAll();

    // Today's schedule
    $today = date('l');
    $stmt = $db->prepare("
        SELECT cs.*, c.course_name, c.course_code 
        FROM class_schedules cs 
        JOIN courses c ON cs.course_id = c.course_id 
        JOIN enrollments e ON c.course_id = e.course_id 
        WHERE e.student_id = ? AND cs.day_of_week = ? 
        ORDER BY cs.start_time ASC
    ");
    $stmt->execute([$user['user_id'], $today]);
    $response['data']['today_schedule'] = $stmt->fetchAll();

    // Recent notifications
    $stmt = $db->prepare("
        SELECT * FROM notifications 
        WHERE user_id = ? 
        ORDER BY created_at DESC LIMIT 10
    ");
    $stmt->execute([$user['user_id']]);
    $response['data']['notifications'] = $stmt->fetchAll();

    // Unread notification count
    $stmt = $db->prepare("
        SELECT COUNT(*) as count FROM notifications 
        WHERE user_id = ? AND is_read = 0
    ");
    $stmt->execute([$user['user_id']]);
    $response['data']['unread_count'] = $stmt->fetch()['count'];

    // Project groups
    $stmt = $db->prepare("
        SELECT pg.*, c.course_name, 
        (SELECT COUNT(*) FROM group_members WHERE group_id = pg.group_id) as member_count
        FROM project_groups pg 
        LEFT JOIN courses c ON pg.course_id = c.course_id
        JOIN group_members gm ON pg.group_id = gm.group_id
        WHERE gm.user_id = ? AND pg.status = 'active'
        ORDER BY pg.created_at DESC LIMIT 3
    ");
    $stmt->execute([$user['user_id']]);
    $response['data']['my_groups'] = $stmt->fetchAll();

    // Recent resources
    $stmt = $db->prepare("
        SELECT r.*, u.full_name as uploader_name, c.course_name
        FROM resources r 
        JOIN users u ON r.uploaded_by = u.user_id
        LEFT JOIN courses c ON r.course_id = c.course_id
        WHERE r.status = 'approved' 
        ORDER BY r.created_at DESC LIMIT 5
    ");
    $stmt->execute();
    $response['data']['recent_resources'] = $stmt->fetchAll();

    // Stats
    $stmt = $db->prepare("
        SELECT 
            (SELECT COUNT(*) FROM enrollments WHERE student_id = ?) as total_courses,
            (SELECT COUNT(*) FROM assignments a JOIN enrollments e ON a.course_id = e.course_id WHERE e.student_id = ? AND a.due_date >= NOW()) as pending_assignments,
            (SELECT COUNT(*) FROM group_members WHERE user_id = ?) as total_groups
    ");
    $stmt->execute([$user['user_id'], $user['user_id'], $user['user_id']]);
    $response['data']['stats'] = $stmt->fetch();

} catch (PDOException $e) {
    $response = ['success' => false, 'message' => $e->getMessage()];
}

echo json_encode($response);
?>