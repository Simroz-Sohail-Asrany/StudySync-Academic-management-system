-- Study Sync Database Schema
-- Created for Software Design and Architecture Project

CREATE DATABASE IF NOT EXISTS studysync;
USE studysync;

-- ============================================
-- USERS & AUTHENTICATION
-- ============================================

CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('student', 'instructor', 'ta', 'admin') DEFAULT 'student',
    department VARCHAR(100),
    profile_picture VARCHAR(255),
    bio TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP NULL
);

CREATE TABLE user_sessions (
    session_id VARCHAR(255) PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(500) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ============================================
-- COURSES & ENROLLMENTS
-- ============================================

CREATE TABLE departments (
    dept_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_name VARCHAR(100) NOT NULL,
    dept_code VARCHAR(20) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE courses (
    course_id INT PRIMARY KEY AUTO_INCREMENT,
    course_code VARCHAR(20) UNIQUE NOT NULL,
    course_name VARCHAR(200) NOT NULL,
    dept_id INT,
    instructor_id INT,
    semester VARCHAR(50),
    year INT,
    description TEXT,
    credits INT DEFAULT 3,
    status ENUM('active', 'inactive', 'completed') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id),
    FOREIGN KEY (instructor_id) REFERENCES users(user_id)
);

CREATE TABLE enrollments (
    enrollment_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('active', 'dropped', 'completed') DEFAULT 'active',
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
    UNIQUE KEY unique_enrollment (student_id, course_id)
);

-- ============================================
-- CLASS SCHEDULE & CALENDAR
-- ============================================

CREATE TABLE class_schedules (
    schedule_id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT NOT NULL,
    day_of_week ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday') NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    room_number VARCHAR(50),
    building VARCHAR(100),
    schedule_type ENUM('lecture', 'lab', 'tutorial', 'seminar') DEFAULT 'lecture',
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);

CREATE TABLE events (
    event_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    event_date DATE NOT NULL,
    start_time TIME,
    end_time TIME,
    event_type ENUM('class', 'exam', 'meeting', 'deadline', 'personal') DEFAULT 'personal',
    color VARCHAR(7) DEFAULT '#6366f1',
    is_all_day BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ============================================
-- ASSIGNMENTS & DEADLINES
-- ============================================

CREATE TABLE assignments (
    assignment_id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    due_date DATETIME NOT NULL,
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    max_marks INT DEFAULT 100,
    assignment_type ENUM('individual', 'group', 'quiz', 'project', 'exam') DEFAULT 'individual',
    instructions TEXT,
    attachments TEXT,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE TABLE assignment_submissions (
    submission_id INT PRIMARY KEY AUTO_INCREMENT,
    assignment_id INT NOT NULL,
    student_id INT NOT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    file_url VARCHAR(500),
    comments TEXT,
    marks_obtained INT,
    feedback TEXT,
    status ENUM('submitted', 'graded', 'late', 'rejected') DEFAULT 'submitted',
    FOREIGN KEY (assignment_id) REFERENCES assignments(assignment_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ============================================
-- PROJECT COLLABORATION
-- ============================================

CREATE TABLE project_groups (
    group_id INT PRIMARY KEY AUTO_INCREMENT,
    group_name VARCHAR(200) NOT NULL,
    course_id INT,
    description TEXT,
    leader_id INT NOT NULL,
    project_deadline DATE,
    status ENUM('planning', 'active', 'completed', 'archived') DEFAULT 'planning',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id),
    FOREIGN KEY (leader_id) REFERENCES users(user_id)
);

CREATE TABLE group_members (
    member_id INT PRIMARY KEY AUTO_INCREMENT,
    group_id INT NOT NULL,
    user_id INT NOT NULL,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    role_in_group ENUM('leader', 'member', 'contributor') DEFAULT 'member',
    FOREIGN KEY (group_id) REFERENCES project_groups(group_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    UNIQUE KEY unique_group_member (group_id, user_id)
);

CREATE TABLE project_tasks (
    task_id INT PRIMARY KEY AUTO_INCREMENT,
    group_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    assigned_to INT,
    created_by INT NOT NULL,
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    status ENUM('todo', 'in_progress', 'review', 'done') DEFAULT 'todo',
    due_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (group_id) REFERENCES project_groups(group_id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_to) REFERENCES users(user_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE TABLE group_discussions (
    discussion_id INT PRIMARY KEY AUTO_INCREMENT,
    group_id INT NOT NULL,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    parent_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (group_id) REFERENCES project_groups(group_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES group_discussions(discussion_id)
);

CREATE TABLE group_files (
    file_id INT PRIMARY KEY AUTO_INCREMENT,
    group_id INT NOT NULL,
    uploaded_by INT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_url VARCHAR(500) NOT NULL,
    file_size INT,
    file_type VARCHAR(100),
    description TEXT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (group_id) REFERENCES project_groups(group_id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by) REFERENCES users(user_id)
);

-- ============================================
-- RESOURCES & MATERIALS
-- ============================================

CREATE TABLE resources (
    resource_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    file_url VARCHAR(500),
    file_type VARCHAR(50),
    file_size INT,
    course_id INT,
    uploaded_by INT NOT NULL,
    resource_type ENUM('notes', 'past_paper', 'slides', 'lab_manual', 'template', 'reference', 'other') DEFAULT 'other',
    tags VARCHAR(500),
    download_count INT DEFAULT 0,
    is_verified BOOLEAN DEFAULT FALSE,
    verified_by INT,
    verified_at TIMESTAMP NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id),
    FOREIGN KEY (uploaded_by) REFERENCES users(user_id),
    FOREIGN KEY (verified_by) REFERENCES users(user_id)
);

CREATE TABLE resource_bookmarks (
    bookmark_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    resource_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (resource_id) REFERENCES resources(resource_id) ON DELETE CASCADE,
    UNIQUE KEY unique_bookmark (user_id, resource_id)
);

CREATE TABLE resource_ratings (
    rating_id INT PRIMARY KEY AUTO_INCREMENT,
    resource_id INT NOT NULL,
    user_id INT NOT NULL,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    review TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (resource_id) REFERENCES resources(resource_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    UNIQUE KEY unique_rating (resource_id, user_id)
);

-- ============================================
-- ANNOUNCEMENTS & NOTIFICATIONS
-- ============================================

CREATE TABLE announcements (
    announcement_id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT,
    posted_by INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    priority ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal',
    is_pinned BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id),
    FOREIGN KEY (posted_by) REFERENCES users(user_id)
);

CREATE TABLE notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT,
    type ENUM('assignment', 'deadline', 'project', 'announcement', 'resource', 'system') DEFAULT 'system',
    reference_id INT,
    reference_type VARCHAR(50),
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ============================================
-- SMART STUDY PLANNER
-- ============================================

CREATE TABLE study_plans (
    plan_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    plan_name VARCHAR(200) NOT NULL,
    week_start DATE NOT NULL,
    week_end DATE NOT NULL,
    total_hours_planned INT DEFAULT 0,
    total_hours_completed INT DEFAULT 0,
    status ENUM('active', 'completed', 'archived') DEFAULT 'active',
    ai_generated BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE study_sessions (
    session_id INT PRIMARY KEY AUTO_INCREMENT,
    plan_id INT NOT NULL,
    task_id INT,
    assignment_id INT,
    session_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    subject VARCHAR(100),
    description TEXT,
    is_completed BOOLEAN DEFAULT FALSE,
    is_break BOOLEAN DEFAULT FALSE,
    priority_level ENUM('low', 'medium', 'high') DEFAULT 'medium',
    FOREIGN KEY (plan_id) REFERENCES study_plans(plan_id) ON DELETE CASCADE,
    FOREIGN KEY (task_id) REFERENCES project_tasks(task_id),
    FOREIGN KEY (assignment_id) REFERENCES assignments(assignment_id)
);

-- ============================================
-- MODERATION & REPORTING
-- ============================================

CREATE TABLE content_reports (
    report_id INT PRIMARY KEY AUTO_INCREMENT,
    reporter_id INT NOT NULL,
    content_type ENUM('resource', 'discussion', 'file', 'user') NOT NULL,
    content_id INT NOT NULL,
    reason ENUM('spam', 'inappropriate', 'plagiarism', 'copyright', 'other') NOT NULL,
    description TEXT,
    status ENUM('pending', 'reviewing', 'resolved', 'dismissed') DEFAULT 'pending',
    handled_by INT,
    resolution TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (reporter_id) REFERENCES users(user_id),
    FOREIGN KEY (handled_by) REFERENCES users(user_id)
);

CREATE TABLE activity_logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id INT,
    details TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- ============================================
-- SAMPLE DATA INSERTION
-- ============================================

INSERT INTO departments (dept_name, dept_code, description) VALUES
('Computer Science', 'CS', 'Department of Computer Science and Software Engineering'),
('Electrical Engineering', 'EE', 'Department of Electrical Engineering'),
('Business Administration', 'BA', 'School of Business and Management'),
('Mathematics', 'MATH', 'Department of Mathematics and Statistics');

INSERT INTO users (email, password_hash, full_name, role, department, bio) VALUES
('admin@studysync.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin', 'IT', 'Platform administrator'),
('dr.ahmed@studysync.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Dr. Ahmed Qaiser', 'instructor', 'Computer Science', 'Professor of Software Engineering'),
('ta.sara@studysync.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Sara Khan', 'ta', 'Computer Science', 'Teaching Assistant for SDA course'),
('simroz@studysync.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Simroz Sohail', 'student', 'Computer Science', 'Group Leader | Passionate about software architecture'),
('amna@studysync.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Amna Khan', 'student', 'Computer Science', 'Development Lead | Full-stack enthusiast'),
('fariha@studysync.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Fariha Karim', 'student', 'Computer Science', 'QA & Documentation Lead | Detail-oriented');

INSERT INTO courses (course_code, course_name, dept_id, instructor_id, semester, year, description, credits) VALUES
('CS-301', 'Software Design and Architecture', 1, 2, 'Spring', 2026, 'Comprehensive course on software design patterns, architecture styles, and system design principles.', 3),
('CS-302', 'Database Management Systems', 1, 2, 'Spring', 2026, 'Advanced database concepts, SQL, normalization, and transaction management.', 3),
('EE-201', 'Digital Logic Design', 2, 2, 'Spring', 2026, 'Boolean algebra, combinational and sequential circuits, FPGA design.', 3);

INSERT INTO enrollments (student_id, course_id) VALUES
(4, 1), (5, 1), (6, 1), (4, 2), (5, 2), (6, 3);

INSERT INTO class_schedules (course_id, day_of_week, start_time, end_time, room_number, building, schedule_type) VALUES
(1, 'Monday', '09:00:00', '11:00:00', 'A-101', 'CS Building', 'lecture'),
(1, 'Wednesday', '09:00:00', '11:00:00', 'A-101', 'CS Building', 'lecture'),
(1, 'Friday', '10:00:00', '12:00:00', 'Lab-3', 'CS Building', 'lab'),
(2, 'Tuesday', '13:00:00', '15:00:00', 'B-205', 'CS Building', 'lecture'),
(2, 'Thursday', '13:00:00', '15:00:00', 'B-205', 'CS Building', 'lecture');

INSERT INTO assignments (course_id, title, description, due_date, priority, assignment_type, created_by) VALUES
(1, 'SDA Project Proposal', 'Submit a comprehensive project proposal including requirements, UML diagrams, and architecture design.', '2026-05-15 23:59:59', 'high', 'group', 2),
(1, 'Design Patterns Assignment', 'Implement 5 design patterns in a real-world scenario with documentation.', '2026-05-20 23:59:59', 'medium', 'individual', 2),
(2, 'SQL Query Optimization', 'Optimize given SQL queries and explain your approach.', '2026-05-18 23:59:59', 'high', 'individual', 2);

INSERT INTO project_groups (group_name, course_id, description, leader_id, project_deadline, status) VALUES
('Team Alpha - Study Sync', 1, 'Academic Collaboration Platform development team', 4, '2026-05-30', 'active');

INSERT INTO group_members (group_id, user_id, role_in_group) VALUES
(1, 4, 'leader'), (1, 5, 'member'), (1, 6, 'member');

INSERT INTO project_tasks (group_id, title, description, assigned_to, created_by, priority, status, due_date) VALUES
(1, 'Design Database Schema', 'Create complete ERD and SQL schema for the platform', 5, 4, 'high', 'in_progress', '2026-05-05'),
(1, 'UI/UX Wireframes', 'Design low-fidelity and high-fidelity mockups', 4, 4, 'high', 'done', '2026-05-01'),
(1, 'Testing Strategy', 'Create comprehensive test plan and test cases', 6, 4, 'medium', 'todo', '2026-05-10'),
(1, 'API Development', 'Develop REST API endpoints for core features', 5, 4, 'high', 'todo', '2026-05-15');

INSERT INTO resources (title, description, course_id, uploaded_by, resource_type, tags, status, is_verified) VALUES
('SDA Lecture Slides Week 1', 'Introduction to Software Architecture and Design Principles', 1, 2, 'slides', 'architecture, design, introduction', 'approved', TRUE),
('Past Paper - SDA 2025', 'Previous year final examination paper with solutions', 1, 2, 'past_paper', 'exam, practice, 2025', 'approved', TRUE),
('Design Patterns Cheat Sheet', 'Quick reference guide for common design patterns', 1, 4, 'notes', 'patterns, reference, quick-guide', 'approved', TRUE),
('SQL Best Practices', 'Comprehensive guide to writing efficient SQL queries', 2, 2, 'reference', 'sql, optimization, database', 'approved', TRUE);

INSERT INTO announcements (course_id, posted_by, title, content, priority, is_pinned) VALUES
(1, 2, 'Project Proposal Deadline Extended', 'The project proposal deadline has been extended to May 15th. Please ensure all requirements are met.', 'high', TRUE),
(1, 2, 'Week 5 Reading Material', 'Please read Chapter 5 on Microservices Architecture before next class.', 'normal', FALSE),
(NULL, 1, 'Platform Maintenance', 'Study Sync will undergo maintenance on May 3rd from 2 AM to 4 AM.', 'normal', FALSE);

INSERT INTO notifications (user_id, title, message, type, reference_id, reference_type) VALUES
(4, 'Assignment Due Soon', 'SDA Project Proposal is due in 14 days', 'deadline', 1, 'assignment'),
(5, 'New Task Assigned', 'You have been assigned: Design Database Schema', 'project', 1, 'task'),
(6, 'New Task Assigned', 'You have been assigned: Testing Strategy', 'project', 3, 'task');

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_courses_instructor ON courses(instructor_id);
CREATE INDEX idx_enrollments_student ON enrollments(student_id);
CREATE INDEX idx_assignments_course ON assignments(course_id);
CREATE INDEX idx_assignments_due_date ON assignments(due_date);
CREATE INDEX idx_project_groups_leader ON project_groups(leader_id);
CREATE INDEX idx_group_members_group ON group_members(group_id);
CREATE INDEX idx_project_tasks_group ON project_tasks(group_id);
CREATE INDEX idx_project_tasks_assigned ON project_tasks(assigned_to);
CREATE INDEX idx_resources_course ON resources(course_id);
CREATE INDEX idx_resources_type ON resources(resource_type);
CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_notifications_read ON notifications(is_read);
CREATE INDEX idx_events_user ON events(user_id);
CREATE INDEX idx_events_date ON events(event_date);
