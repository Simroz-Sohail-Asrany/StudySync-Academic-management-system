<?php
// Study Sync - Configuration File
// Database credentials - Update these for your environment

define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'studysync');
define('DB_CHARSET', 'utf8mb4');

// Application Settings
define('APP_NAME', 'Study Sync');
define('APP_URL', 'http://localhost/studysync');
define('APP_VERSION', '1.0.0');

// Security Settings
define('JWT_SECRET', 'studysync_secret_key_2026_change_in_production');
define('SESSION_LIFETIME', 86400); // 24 hours
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_DURATION', 900); // 15 minutes

// File Upload Settings
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_FILE_TYPES', ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'zip', 'jpg', 'png', 'txt', 'xls', 'xlsx']);
define('UPLOAD_PATH', __DIR__ . '/../uploads/');

// Email Settings (for notifications)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'studysync@university.edu');
define('SMTP_PASS', '');

// Error Reporting
define('DEBUG_MODE', true);
if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Timezone
date_default_timezone_set('Asia/Karachi');
?>