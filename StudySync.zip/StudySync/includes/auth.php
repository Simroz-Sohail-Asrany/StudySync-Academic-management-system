<?php
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/../vendor/autoload.php'; // For JWT if using composer

class Auth {
    private $db;
    private $secret;

    public function __construct() {
        $this->db = getDB();
        $this->secret = JWT_SECRET;
    }

    // Simple token generation (for production, use proper JWT library)
    public function generateToken($userId, $email, $role) {
        $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
        $time = time();
        $payload = json_encode([
            'iss' => APP_NAME,
            'iat' => $time,
            'exp' => $time + SESSION_LIFETIME,
            'sub' => $userId,
            'email' => $email,
            'role' => $role
        ]);

        $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));

        $signature = hash_hmac('sha256', $base64Header . "." . $base64Payload, $this->secret, true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

        return $base64Header . "." . $base64Payload . "." . $base64Signature;
    }

    public function verifyToken($token) {
        $parts = explode('.', $token);
        if (count($parts) !== 3) return false;

        $signature = hash_hmac('sha256', $parts[0] . "." . $parts[1], $this->secret, true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

        if (!hash_equals($base64Signature, $parts[2])) return false;

        $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $parts[1])), true);

        if ($payload['exp'] < time()) return false;

        return $payload;
    }

    public function login($email, $password) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            // Update last login
            $update = $this->db->prepare("UPDATE users SET last_login = NOW() WHERE user_id = ?");
            $update->execute([$user['user_id']]);

            $token = $this->generateToken($user['user_id'], $user['email'], $user['role']);

            // Store session
            $sessionId = bin2hex(random_bytes(32));
            $stmt = $this->db->prepare("INSERT INTO user_sessions (session_id, user_id, token, expires_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? SECOND))");
            $stmt->execute([$sessionId, $user['user_id'], $token, SESSION_LIFETIME]);

            return [
                'success' => true,
                'token' => $token,
                'session_id' => $sessionId,
                'user' => [
                    'id' => $user['user_id'],
                    'name' => $user['full_name'],
                    'email' => $user['email'],
                    'role' => $user['role'],
                    'department' => $user['department']
                ]
            ];
        }

        return ['success' => false, 'message' => 'Invalid credentials'];
    }

    public function register($email, $password, $fullName, $department, $role = 'student') {
        // Check if email exists
        $stmt = $this->db->prepare("SELECT user_id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            return ['success' => false, 'message' => 'Email already registered'];
        }

        $passwordHash = password_hash($password, PASSWORD_BCRYPT);

        $stmt = $this->db->prepare("INSERT INTO users (email, password_hash, full_name, role, department) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$email, $passwordHash, $fullName, $role, $department]);

        $userId = $this->db->lastInsertId();

        return [
            'success' => true,
            'message' => 'Registration successful',
            'user_id' => $userId
        ];
    }

    public function getCurrentUser() {
        $headers = getallheaders();
        $authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : '';

        if (preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
            $token = $matches[1];
            $payload = $this->verifyToken($token);

            if ($payload) {
                $stmt = $this->db->prepare("SELECT user_id, full_name, email, role, department, profile_picture, bio FROM users WHERE user_id = ?");
                $stmt->execute([$payload['sub']]);
                return $stmt->fetch();
            }
        }

        // Check session
        if (isset($_SESSION['user_id'])) {
            $stmt = $this->db->prepare("SELECT user_id, full_name, email, role, department, profile_picture, bio FROM users WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            return $stmt->fetch();
        }

        return null;
    }

    public function logout($userId) {
        $stmt = $this->db->prepare("DELETE FROM user_sessions WHERE user_id = ?");
        $stmt->execute([$userId]);
        session_destroy();
        return ['success' => true];
    }
}

// Helper function
function requireAuth() {
    $auth = new Auth();
    $user = $auth->getCurrentUser();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }
    return $user;
}

function requireRole($roles) {
    $user = requireAuth();
    if (!in_array($user['role'], (array)$roles)) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden - Insufficient permissions']);
        exit;
    }
    return $user;
}
?>