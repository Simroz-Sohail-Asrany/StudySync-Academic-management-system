<?php
require_once __DIR__ . '/config.php';

class Database {
    private $host = DB_HOST;
    private $db_name = DB_NAME;
    private $username = DB_USERNAME;
    private $password = DB_PASSWORD;
    private $charset = DB_CHARSET;
    public $conn;

    public function connect() {
        $this->conn = null;

        try {
            $dsn = "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=" . $this->charset;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];

            $this->conn = new PDO($dsn, $this->username, $this->password, $options);
        } catch(PDOException $e) {
            if (DEBUG_MODE) {
                echo "Connection Error: " . $e->getMessage();
            }
            // Log error for production
            error_log("Database connection failed: " . $e->getMessage());
        }

        return $this->conn;
    }

    public function close() {
        $this->conn = null;
    }
}

// Helper function to get DB instance
function getDB() {
    $database = new Database();
    return $database->connect();
}
?>