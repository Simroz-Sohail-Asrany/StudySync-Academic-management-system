# Study Sync - Academic Collaboration Platform

## Software Design and Architecture (SDA) Project

### Team Members
- **Simroz Sohail (24k-0746)** - Group Leader / Project Lead
- **Amna Khan (24k-0561)** - Development Lead  
- **Fariha Karim (24k-1015)** - QA & Documentation Lead

### Project Overview
Study Sync is a comprehensive web-based academic productivity and collaboration platform designed for university students. It centralizes assignment tracking, class scheduling, project collaboration, and resource sharing into one unified system.

### Features
- **User Authentication & Role Management** - Secure login with role-based access (Student, Instructor, TA, Admin)
- **Assignment Tracking** - Centralized deadline management with priority tags and reminders
- **Class Schedule & Calendar** - Weekly timetable with room details and calendar view
- **Project Collaboration** - Kanban-style task boards, file sharing, and group discussions
- **Resource Library** - Searchable repository of notes, past papers, slides, and templates
- **Smart Study Planner** - AI-assisted weekly schedule optimization
- **Notifications System** - Real-time alerts for deadlines, announcements, and updates
- **Admin Dashboard** - User management, content moderation, and system monitoring

### Tech Stack
- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Backend**: PHP 7.4+ with PDO
- **Database**: MySQL 5.7+
- **Authentication**: JWT-based token authentication
- **Styling**: Custom CSS with modern dark theme design

### Installation

1. **Requirements**
   - PHP 7.4 or higher
   - MySQL 5.7 or higher
   - Apache web server with mod_rewrite enabled
   - Composer (optional, for JWT library)

2. **Database Setup**
   ```bash
   mysql -u root -p
   SOURCE database/schema.sql;
   ```

3. **Configuration**
   - Update `includes/config.php` with your database credentials
   - Change JWT_SECRET to a secure random string for production
   - Set APP_URL to your domain

4. **File Permissions**
   ```bash
   chmod 755 uploads/
   chmod 644 includes/config.php
   ```

5. **Access the Application**
   - Navigate to `http://localhost/studysync/login.html`
   - Demo credentials: `simroz@studysync.edu` / `password`

### Database Schema
The schema includes tables for:
- Users & Authentication
- Courses & Enrollments
- Class Schedules & Events
- Assignments & Submissions
- Project Groups, Tasks, Discussions, Files
- Resources, Bookmarks, Ratings
- Announcements & Notifications
- Study Plans & Sessions
- Content Reports & Activity Logs

### API Endpoints
- `POST/GET api/auth.php` - Authentication (login, register, logout)
- `GET api/dashboard.php` - Dashboard data aggregation
- `GET/POST api/assignments.php` - Assignment management
- `GET/POST api/projects.php` - Project collaboration
- `GET/POST api/resources.php` - Resource library
- `GET/POST api/calendar.php` - Calendar events
- `GET/PUT api/notifications.php` - Notifications

### Security Features
- Password hashing with bcrypt
- JWT token-based authentication
- SQL injection prevention via prepared statements
- XSS protection with output encoding
- CSRF token validation
- Rate limiting on login attempts
- Secure file upload validation

### Project Structure
```
StudySync/
├── api/              # REST API endpoints
├── assets/           # CSS, JS, images
├── database/         # SQL schema and migrations
├── includes/         # PHP configuration and helpers
├── pages/            # Additional page templates
├── uploads/          # User uploaded files
├── index.html        # Main dashboard
├── login.html        # Authentication page
└── .htaccess         # Apache configuration
```

### License
This project is created for educational purposes as part of the Software Design and Architecture course.

### Instructor
Dr. Ahmed Qaiser
