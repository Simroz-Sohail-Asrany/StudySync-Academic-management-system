// Study Sync - Main Application JavaScript

class StudySyncApp {
    constructor() {
        this.apiBase = 'api/';
        this.token = localStorage.getItem('studysync_token');
        this.user = JSON.parse(localStorage.getItem('studysync_user') || 'null');
        this.currentPage = 'dashboard';
        this.init();
    }

    init() {
        if (!this.token && !window.location.pathname.includes('login')) {
            window.location.href = 'login.html';
            return;
        }

        if (this.token) {
            this.setupEventListeners();
            this.loadNavigation();
            this.loadPage(this.currentPage);
            this.startNotificationPolling();
        }
    }

    async api(endpoint, options = {}) {
        const url = this.apiBase + endpoint;
        const config = {
            headers: {
                'Authorization': `Bearer ${this.token}`,
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        };

        if (config.body && typeof config.body === 'object') {
            config.body = JSON.stringify(config.body);
        }

        try {
            const response = await fetch(url, config);
            const data = await response.json();

            if (response.status === 401) {
                this.logout();
                return null;
            }

            return data;
        } catch (error) {
            console.error('API Error:', error);
            this.showToast('Network error. Please try again.', 'error');
            return null;
        }
    }

    setupEventListeners() {
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = item.dataset.page;
                if (page) {
                    this.loadPage(page);
                    this.setActiveNav(item);
                }
            });
        });

        const menuToggle = document.getElementById('menuToggle');
        if (menuToggle) {
            menuToggle.addEventListener('click', () => {
                document.querySelector('.sidebar').classList.toggle('open');
            });
        }

        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.logout());
        }

        const notifBtn = document.getElementById('notificationBtn');
        if (notifBtn) {
            notifBtn.addEventListener('click', () => this.toggleNotifications());
        }
    }

    setActiveNav(activeItem) {
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        activeItem.classList.add('active');
    }

    loadNavigation() {
        if (this.user) {
            const userNameEl = document.getElementById('userName');
            const userRoleEl = document.getElementById('userRole');
            const userAvatarEl = document.getElementById('userAvatar');

            if (userNameEl) userNameEl.textContent = this.user.name;
            if (userRoleEl) userRoleEl.textContent = this.user.role;
            if (userAvatarEl) userAvatarEl.textContent = this.user.name.charAt(0).toUpperCase();
        }
    }

    async loadPage(page) {
        this.currentPage = page;
        const contentArea = document.getElementById('contentArea');
        contentArea.innerHTML = '<div class="flex items-center justify-center" style="height: 400px;"><div class="loading-spinner"></div></div>';

        switch(page) {
            case 'dashboard':
                await this.loadDashboard(contentArea);
                break;
            case 'assignments':
                await this.loadAssignments(contentArea);
                break;
            case 'projects':
                await this.loadProjects(contentArea);
                break;
            case 'calendar':
                await this.loadCalendar(contentArea);
                break;
            case 'resources':
                await this.loadResources(contentArea);
                break;
            case 'schedule':
                await this.loadSchedule(contentArea);
                break;
            default:
                await this.loadDashboard(contentArea);
        }

        const pageTitle = document.getElementById('pageTitle');
        const pageSubtitle = document.getElementById('pageSubtitle');
        if (pageTitle) {
            const titles = {
                dashboard: 'Dashboard',
                assignments: 'Assignments',
                projects: 'Project Collaboration',
                calendar: 'Calendar',
                resources: 'Resource Library',
                schedule: 'Class Schedule'
            };
            pageTitle.textContent = titles[page] || 'Dashboard';
        }
        if (pageSubtitle) {
            const subtitles = {
                dashboard: 'Overview of your academic activities',
                assignments: 'Track and manage your assignments',
                projects: 'Collaborate with your team members',
                calendar: 'View your schedule and deadlines',
                resources: 'Access study materials and notes',
                schedule: 'Your weekly class timetable'
            };
            pageSubtitle.textContent = subtitles[page] || '';
        }
    }

    async loadDashboard(container) {
        const data = await this.api('dashboard.php');
        if (!data || !data.success) {
            container.innerHTML = '<div class="empty-state"><div class="empty-state-title">Failed to load dashboard</div></div>';
            return;
        }

        const stats = data.data.stats || {};
        const deadlines = data.data.upcoming_deadlines || [];
        const schedule = data.data.today_schedule || [];
        const groups = data.data.my_groups || [];
        const resources = data.data.recent_resources || [];

        container.innerHTML = `
            <div class="animate-fade-in">
                <div class="card-grid">
                    <div class="card">
                        <div class="card-header">
                            <div><div class="card-title">Enrolled Courses</div><div class="card-value">${stats.total_courses || 0}</div></div>
                            <div class="card-icon primary"><i class="fas fa-book"></i></div>
                        </div>
                        <div class="card-change positive"><i class="fas fa-arrow-up"></i> Active this semester</div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <div><div class="card-title">Pending Assignments</div><div class="card-value">${stats.pending_assignments || 0}</div></div>
                            <div class="card-icon warning"><i class="fas fa-tasks"></i></div>
                        </div>
                        <div class="card-change ${stats.pending_assignments > 3 ? 'negative' : 'positive'}">
                            ${stats.pending_assignments > 3 ? '<i class="fas fa-exclamation-circle"></i> High workload' : '<i class="fas fa-check"></i> On track'}
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <div><div class="card-title">Project Groups</div><div class="card-value">${stats.total_groups || 0}</div></div>
                            <div class="card-icon success"><i class="fas fa-users"></i></div>
                        </div>
                        <div class="card-change positive"><i class="fas fa-users"></i> Active collaborations</div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <div><div class="card-title">Unread Notifications</div><div class="card-value">${data.data.unread_count || 0}</div></div>
                            <div class="card-icon info"><i class="fas fa-bell"></i></div>
                        </div>
                        <div class="card-change ${data.data.unread_count > 0 ? 'warning' : 'positive'}">
                            ${data.data.unread_count > 0 ? '<i class="fas fa-bell"></i> Check updates' : '<i class="fas fa-check"></i> All caught up'}
                        </div>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
                    <div>
                        <div class="content-card">
                            <div class="content-card-header">
                                <div class="content-card-title"><i class="fas fa-clock"></i> Upcoming Deadlines</div>
                                <button class="btn btn-ghost btn-sm" onclick="app.loadPage('assignments')">View All</button>
                            </div>
                            <div class="content-card-body">
                                ${deadlines.length > 0 ? `
                                    <div class="deadline-list">
                                        ${deadlines.map(d => `
                                            <div class="deadline-item" style="display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--border-color);">
                                                <div style="width: 48px; height: 48px; background: ${this.getPriorityColor(d.priority)}20; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; color: ${this.getPriorityColor(d.priority)}; font-size: 20px;">
                                                    <i class="fas fa-file-alt"></i>
                                                </div>
                                                <div style="flex: 1;">
                                                    <div style="font-weight: 600; margin-bottom: 4px;">${d.title}</div>
                                                    <div style="font-size: 13px; color: var(--text-muted);">${d.course_code} - ${d.course_name}</div>
                                                </div>
                                                <div style="text-align: right;">
                                                    <div style="font-size: 13px; font-weight: 600; color: ${this.getPriorityColor(d.priority)};">${this.formatDate(d.due_date)}</div>
                                                    <div style="font-size: 12px; color: var(--text-muted);">${this.getTimeLeft(d.due_date)}</div>
                                                </div>
                                            </div>
                                        `).join('')}
                                    </div>
                                ` : `
                                    <div class="empty-state" style="padding: 40px;">
                                        <div class="empty-state-icon">📚</div>
                                        <div class="empty-state-title">No upcoming deadlines</div>
                                        <div class="empty-state-text">You are all caught up! Enjoy your free time.</div>
                                    </div>
                                `}
                            </div>
                        </div>

                        <div class="content-card">
                            <div class="content-card-header">
                                <div class="content-card-title"><i class="fas fa-project-diagram"></i> My Project Groups</div>
                                <button class="btn btn-ghost btn-sm" onclick="app.loadPage('projects')">View All</button>
                            </div>
                            <div class="content-card-body">
                                ${groups.length > 0 ? `
                                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 16px;">
                                        ${groups.map(g => `
                                            <div class="card" style="cursor: pointer;" onclick="app.loadGroupDetail(${g.group_id})">
                                                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, var(--primary), var(--secondary)); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; font-size: 16px;">
                                                        <i class="fas fa-users"></i>
                                                    </div>
                                                    <div>
                                                        <div style="font-weight: 600; font-size: 14px;">${g.group_name}</div>
                                                        <div style="font-size: 12px; color: var(--text-muted);">${g.course_name || 'General'}</div>
                                                    </div>
                                                </div>
                                                <div style="display: flex; gap: 12px; font-size: 12px; color: var(--text-muted);">
                                                    <span><i class="fas fa-users"></i> ${g.member_count} members</span>
                                                    <span><i class="fas fa-tasks"></i> ${g.pending_tasks} tasks</span>
                                                </div>
                                                ${g.project_deadline ? `
                                                    <div style="margin-top: 12px; font-size: 12px; color: var(--danger);">
                                                        <i class="fas fa-calendar"></i> Due: ${this.formatDate(g.project_deadline)}
                                                    </div>
                                                ` : ''}
                                            </div>
                                        `).join('')}
                                    </div>
                                ` : `
                                    <div class="empty-state" style="padding: 40px;">
                                        <div class="empty-state-icon">🤝</div>
                                        <div class="empty-state-title">No project groups yet</div>
                                        <div class="empty-state-text">Join or create a project group to start collaborating.</div>
                                    </div>
                                `}
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="content-card">
                            <div class="content-card-header">
                                <div class="content-card-title"><i class="fas fa-calendar-day"></i> Today's Schedule</div>
                                <div style="font-size: 12px; color: var(--text-muted);">${new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</div>
                            </div>
                            <div class="content-card-body">
                                ${schedule.length > 0 ? `
                                    <div class="schedule-list">
                                        ${schedule.map(s => `
                                            <div style="display: flex; gap: 12px; padding: 12px 0; border-bottom: 1px solid var(--border-color);">
                                                <div style="text-align: center; min-width: 60px;">
                                                    <div style="font-size: 13px; font-weight: 700; color: var(--primary-light);">${s.start_time.substring(0, 5)}</div>
                                                    <div style="font-size: 11px; color: var(--text-muted);">${s.end_time.substring(0, 5)}</div>
                                                </div>
                                                <div style="flex: 1;">
                                                    <div style="font-weight: 600; font-size: 14px;">${s.course_name}</div>
                                                    <div style="font-size: 12px; color: var(--text-muted);">
                                                        <i class="fas fa-map-marker-alt"></i> ${s.room_number}, ${s.building}
                                                    </div>
                                                    <div style="font-size: 11px; color: var(--text-muted); text-transform: capitalize;">${s.schedule_type}</div>
                                                </div>
                                            </div>
                                        `).join('')}
                                    </div>
                                ` : `
                                    <div class="empty-state" style="padding: 32px;">
                                        <div class="empty-state-icon">📅</div>
                                        <div class="empty-state-title">No classes today</div>
                                        <div class="empty-state-text">Enjoy your day off!</div>
                                    </div>
                                `}
                            </div>
                        </div>

                        <div class="content-card">
                            <div class="content-card-header">
                                <div class="content-card-title"><i class="fas fa-book-open"></i> Recent Resources</div>
                            </div>
                            <div class="content-card-body">
                                ${resources.length > 0 ? `
                                    <div class="resource-list">
                                        ${resources.slice(0, 5).map(r => `
                                            <div style="display: flex; align-items: center; gap: 12px; padding: 12px 0; border-bottom: 1px solid var(--border-color); cursor: pointer;" onclick="app.loadPage('resources')">
                                                <div style="width: 36px; height: 36px; background: ${this.getResourceTypeColor(r.resource_type)}20; border-radius: var(--radius-sm); display: flex; align-items: center; justify-content: center; color: ${this.getResourceTypeColor(r.resource_type)}; font-size: 14px;">
                                                    <i class="fas ${this.getResourceTypeIcon(r.resource_type)}"></i>
                                                </div>
                                                <div style="flex: 1; min-width: 0;">
                                                    <div style="font-weight: 600; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${r.title}</div>
                                                    <div style="font-size: 11px; color: var(--text-muted);">${r.uploader_name} • ${this.formatDate(r.created_at)}</div>
                                                </div>
                                            </div>
                                        `).join('')}
                                    </div>
                                ` : `
                                    <div class="empty-state" style="padding: 32px;">
                                        <div class="empty-state-icon">📖</div>
                                        <div class="empty-state-title">No resources yet</div>
                                    </div>
                                `}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    async loadAssignments(container) {
        const data = await this.api('assignments.php');
        if (!data || !data.success) {
            container.innerHTML = '<div class="empty-state"><div class="empty-state-title">Failed to load assignments</div></div>';
            return;
        }

        const assignments = data.assignments || [];

        container.innerHTML = `
            <div class="animate-fade-in">
                <div class="content-card">
                    <div class="content-card-header">
                        <div class="content-card-title"><i class="fas fa-tasks"></i> All Assignments</div>
                        <div class="flex gap-2">
                            <select class="form-select" style="width: 150px;" onchange="app.filterAssignments(this.value)">
                                <option value="all">All Status</option>
                                <option value="upcoming">Upcoming</option>
                                <option value="overdue">Overdue</option>
                            </select>
                            <button class="btn btn-primary btn-sm" onclick="app.showAddAssignmentModal()">
                                <i class="fas fa-plus"></i> New Assignment
                            </button>
                        </div>
                    </div>
                    <div class="content-card-body">
                        ${assignments.length > 0 ? `
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Assignment</th>
                                        <th>Course</th>
                                        <th>Due Date</th>
                                        <th>Priority</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${assignments.map(a => `
                                        <tr>
                                            <td>
                                                <div style="font-weight: 600;">${a.title}</div>
                                                <div style="font-size: 12px; color: var(--text-muted);">${a.assignment_type}</div>
                                            </td>
                                            <td>
                                                <div style="font-weight: 500;">${a.course_code}</div>
                                                <div style="font-size: 12px; color: var(--text-muted);">${a.course_name}</div>
                                            </td>
                                            <td>
                                                <div style="font-weight: 600; color: ${new Date(a.due_date) < new Date() ? 'var(--danger)' : 'var(--text-primary)'}">
                                                    ${this.formatDate(a.due_date)}
                                                </div>
                                                <div style="font-size: 12px; color: var(--text-muted);">${this.getTimeLeft(a.due_date)}</div>
                                            </td>
                                            <td>
                                                <span class="badge badge-${a.priority === 'high' || a.priority === 'urgent' ? 'danger' : a.priority === 'medium' ? 'warning' : 'success'}">
                                                    ${a.priority}
                                                </span>
                                            </td>
                                            <td>
                                                ${a.submitted > 0 
                                                    ? '<span class="badge badge-success"><i class="fas fa-check"></i> Submitted</span>'
                                                    : '<span class="badge badge-warning"><i class="fas fa-clock"></i> Pending</span>'
                                                }
                                            </td>
                                            <td>
                                                <button class="btn btn-ghost btn-sm" onclick="app.viewAssignment(${a.assignment_id})">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        ` : `
                            <div class="empty-state">
                                <div class="empty-state-icon">📝</div>
                                <div class="empty-state-title">No assignments found</div>
                                <div class="empty-state-text">You are all caught up!</div>
                            </div>
                        `}
                    </div>
                </div>
            </div>
        `;
    }

    async loadProjects(container) {
        const data = await this.api('projects.php');
        if (!data || !data.success) {
            container.innerHTML = '<div class="empty-state"><div class="empty-state-title">Failed to load projects</div></div>';
            return;
        }

        const groups = data.groups || [];

        container.innerHTML = `
            <div class="animate-fade-in">
                <div class="flex justify-between items-center mb-4">
                    <div class="tabs">
                        <button class="tab active">All Groups</button>
                        <button class="tab">Active</button>
                        <button class="tab">Completed</button>
                    </div>
                    <button class="btn btn-primary" onclick="app.showCreateGroupModal()">
                        <i class="fas fa-plus"></i> Create Group
                    </button>
                </div>

                <div class="card-grid">
                    ${groups.length > 0 ? groups.map(g => `
                        <div class="card" style="cursor: pointer;" onclick="app.loadGroupDetail(${g.group_id})">
                            <div class="card-header">
                                <div>
                                    <div style="font-size: 18px; font-weight: 700; margin-bottom: 4px;">${g.group_name}</div>
                                    <div style="font-size: 13px; color: var(--text-muted);">${g.course_name || 'General Project'}</div>
                                </div>
                                <div class="card-icon primary"><i class="fas fa-users"></i></div>
                            </div>
                            <div style="margin-bottom: 16px;">
                                <div style="display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 8px;">
                                    <span style="color: var(--text-muted);">Progress</span>
                                    <span style="font-weight: 600;">${Math.round(((g.pending_tasks || 0) / (g.pending_tasks + 5 || 1)) * 100)}%</span>
                                </div>
                                <div class="progress-bar">
                                    <div class="progress-fill" style="width: ${Math.round(((g.pending_tasks || 0) / (g.pending_tasks + 5 || 1)) * 100)}%"></div>
                                </div>
                            </div>
                            <div style="display: flex; justify-content: space-between; font-size: 13px; color: var(--text-muted);">
                                <span><i class="fas fa-users"></i> ${g.member_count} members</span>
                                <span><i class="fas fa-tasks"></i> ${g.pending_tasks} pending</span>
                            </div>
                            ${g.project_deadline ? `
                                <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-color); font-size: 13px; color: var(--danger);">
                                    <i class="fas fa-calendar-alt"></i> Deadline: ${this.formatDate(g.project_deadline)}
                                </div>
                            ` : ''}
                        </div>
                    `).join('') : `
                        <div class="empty-state" style="grid-column: 1 / -1;">
                            <div class="empty-state-icon">🚀</div>
                            <div class="empty-state-title">No project groups yet</div>
                            <div class="empty-state-text">Create a new group or join an existing one to start collaborating.</div>
                            <button class="btn btn-primary mt-3" onclick="app.showCreateGroupModal()">
                                <i class="fas fa-plus"></i> Create Your First Group
                            </button>
                        </div>
                    `}
                </div>
            </div>
        `;
    }

    async loadGroupDetail(groupId) {
        const container = document.getElementById('contentArea');
        container.innerHTML = '<div class="flex items-center justify-center" style="height: 400px;"><div class="loading-spinner"></div></div>';

        const data = await this.api(`projects.php?group_id=${groupId}`);
        if (!data || !data.success) {
            this.showToast('Failed to load group details', 'error');
            return;
        }

        const group = data.group;
        const tasks = data.tasks || [];
        const members = data.members || [];
        const discussions = data.discussions || [];
        const files = data.files || [];

        const todoTasks = tasks.filter(t => t.status === 'todo');
        const inProgressTasks = tasks.filter(t => t.status === 'in_progress');
        const reviewTasks = tasks.filter(t => t.status === 'review');
        const doneTasks = tasks.filter(t => t.status === 'done');

        container.innerHTML = `
            <div class="animate-fade-in">
                <div class="flex items-center gap-3 mb-6">
                    <button class="btn btn-ghost btn-sm" onclick="app.loadPage('projects')">
                        <i class="fas fa-arrow-left"></i> Back
                    </button>
                    <div>
                        <div style="font-size: 24px; font-weight: 800;">${group.group_name}</div>
                        <div style="font-size: 14px; color: var(--text-muted);">${group.course_name || 'General'} • Led by ${group.leader_name}</div>
                    </div>
                </div>

                <div class="tabs mb-4">
                    <button class="tab active" onclick="app.switchGroupTab(this, 'board')">Task Board</button>
                    <button class="tab" onclick="app.switchGroupTab(this, 'members')">Members (${members.length})</button>
                    <button class="tab" onclick="app.switchGroupTab(this, 'discussions')">Discussions</button>
                    <button class="tab" onclick="app.switchGroupTab(this, 'files')">Files</button>
                </div>

                <div id="groupTab-board" class="group-tab-content">
                    <div class="flex justify-between items-center mb-4">
                        <div style="font-size: 14px; color: var(--text-muted);">
                            <i class="fas fa-info-circle"></i> Drag tasks to update status
                        </div>
                        <button class="btn btn-primary btn-sm" onclick="app.showAddTaskModal(${groupId})">
                            <i class="fas fa-plus"></i> Add Task
                        </button>
                    </div>
                    <div class="kanban-board">
                        <div class="kanban-column">
                            <div class="kanban-column-header">
                                <div class="kanban-column-title">
                                    <span style="width: 8px; height: 8px; background: var(--text-muted); border-radius: 50%;"></span>
                                    To Do
                                </div>
                                <span class="kanban-count">${todoTasks.length}</span>
                            </div>
                            ${todoTasks.map(t => this.renderKanbanCard(t, groupId)).join('')}
                        </div>
                        <div class="kanban-column">
                            <div class="kanban-column-header">
                                <div class="kanban-column-title">
                                    <span style="width: 8px; height: 8px; background: var(--primary); border-radius: 50%;"></span>
                                    In Progress
                                </div>
                                <span class="kanban-count">${inProgressTasks.length}</span>
                            </div>
                            ${inProgressTasks.map(t => this.renderKanbanCard(t, groupId)).join('')}
                        </div>
                        <div class="kanban-column">
                            <div class="kanban-column-header">
                                <div class="kanban-column-title">
                                    <span style="width: 8px; height: 8px; background: var(--warning); border-radius: 50%;"></span>
                                    Review
                                </div>
                                <span class="kanban-count">${reviewTasks.length}</span>
                            </div>
                            ${reviewTasks.map(t => this.renderKanbanCard(t, groupId)).join('')}
                        </div>
                        <div class="kanban-column">
                            <div class="kanban-column-header">
                                <div class="kanban-column-title">
                                    <span style="width: 8px; height: 8px; background: var(--success); border-radius: 50%;"></span>
                                    Done
                                </div>
                                <span class="kanban-count">${doneTasks.length}</span>
                            </div>
                            ${doneTasks.map(t => this.renderKanbanCard(t, groupId)).join('')}
                        </div>
                    </div>
                </div>

                <div id="groupTab-members" class="group-tab-content hidden">
                    <div class="content-card">
                        <div class="content-card-header">
                            <div class="content-card-title"><i class="fas fa-users"></i> Group Members</div>
                            <button class="btn btn-primary btn-sm" onclick="app.showAddMemberModal(${groupId})">
                                <i class="fas fa-user-plus"></i> Add Member
                            </button>
                        </div>
                        <div class="content-card-body">
                            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px;">
                                ${members.map(m => `
                                    <div class="card" style="display: flex; align-items: center; gap: 16px;">
                                        <div class="user-avatar" style="width: 48px; height: 48px; font-size: 18px;">
                                            ${m.full_name.charAt(0).toUpperCase()}
                                        </div>
                                        <div style="flex: 1;">
                                            <div style="font-weight: 600;">${m.full_name}</div>
                                            <div style="font-size: 13px; color: var(--text-muted);">${m.email}</div>
                                            <span class="badge badge-${m.role_in_group === 'leader' ? 'primary' : 'secondary'}" style="margin-top: 4px;">
                                                ${m.role_in_group}
                                            </span>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                </div>

                <div id="groupTab-discussions" class="group-tab-content hidden">
                    <div class="content-card">
                        <div class="content-card-header">
                            <div class="content-card-title"><i class="fas fa-comments"></i> Group Discussions</div>
                        </div>
                        <div class="content-card-body">
                            <div style="margin-bottom: 20px;">
                                <textarea class="form-textarea" id="discussionInput" placeholder="Write a message..."></textarea>
                                <button class="btn btn-primary mt-2" onclick="app.postDiscussion(${groupId})">
                                    <i class="fas fa-paper-plane"></i> Send
                                </button>
                            </div>
                            <div class="discussion-list">
                                ${discussions.length > 0 ? discussions.map(d => `
                                    <div style="display: flex; gap: 12px; padding: 16px 0; border-bottom: 1px solid var(--border-color);">
                                        <div class="user-avatar" style="width: 36px; height: 36px; font-size: 14px;">
                                            ${d.full_name.charAt(0).toUpperCase()}
                                        </div>
                                        <div style="flex: 1;">
                                            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
                                                <span style="font-weight: 600; font-size: 14px;">${d.full_name}</span>
                                                <span style="font-size: 12px; color: var(--text-muted);">${this.formatDate(d.created_at)}</span>
                                            </div>
                                            <div style="font-size: 14px; color: var(--text-secondary); line-height: 1.5;">${d.message}</div>
                                        </div>
                                    </div>
                                `).join('') : `
                                    <div class="empty-state" style="padding: 40px;">
                                        <div class="empty-state-icon">💬</div>
                                        <div class="empty-state-title">No discussions yet</div>
                                        <div class="empty-state-text">Start the conversation by posting a message above.</div>
                                    </div>
                                `}
                            </div>
                        </div>
                    </div>
                </div>

                <div id="groupTab-files" class="group-tab-content hidden">
                    <div class="content-card">
                        <div class="content-card-header">
                            <div class="content-card-title"><i class="fas fa-folder-open"></i> Shared Files</div>
                            <button class="btn btn-primary btn-sm">
                                <i class="fas fa-upload"></i> Upload File
                            </button>
                        </div>
                        <div class="content-card-body">
                            ${files.length > 0 ? `
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>File</th>
                                            <th>Uploaded By</th>
                                            <th>Date</th>
                                            <th>Size</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${files.map(f => `
                                            <tr>
                                                <td>
                                                    <div style="display: flex; align-items: center; gap: 10px;">
                                                        <i class="fas fa-file" style="color: var(--primary-light);"></i>
                                                        <span style="font-weight: 500;">${f.file_name}</span>
                                                    </div>
                                                </td>
                                                <td>${f.uploader_name}</td>
                                                <td>${this.formatDate(f.uploaded_at)}</td>
                                                <td>${this.formatFileSize(f.file_size)}</td>
                                                <td>
                                                    <a href="${f.file_url}" class="btn btn-ghost btn-sm" target="_blank">
                                                        <i class="fas fa-download"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            ` : `
                                <div class="empty-state" style="padding: 40px;">
                                    <div class="empty-state-icon">📁</div>
                                    <div class="empty-state-title">No files shared yet</div>
                                    <div class="empty-state-text">Upload files to share with your group members.</div>
                                </div>
                            `}
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderKanbanCard(task, groupId) {
        return `
            <div class="kanban-card" draggable="true" data-task-id="${task.task_id}">
                <div class="kanban-card-title">${task.title}</div>
                <div style="font-size: 12px; color: var(--text-muted); margin-bottom: 8px;">${task.description || 'No description'}</div>
                <div class="kanban-card-meta">
                    ${task.assigned_to_name ? `<span><i class="fas fa-user"></i> ${task.assigned_to_name}</span>` : ''}
                    ${task.due_date ? `<span><i class="fas fa-calendar"></i> ${this.formatDate(task.due_date)}</span>` : ''}
                    <span class="priority-${task.priority}"><i class="fas fa-flag"></i> ${task.priority}</span>
                </div>
            </div>
        `;
    }

    switchGroupTab(tabEl, tabName) {
        document.querySelectorAll('.group-tab-content').forEach(el => el.classList.add('hidden'));
        document.getElementById(`groupTab-${tabName}`).classList.remove('hidden');

        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        tabEl.classList.add('active');
    }

    async loadCalendar(container) {
        const now = new Date();
        const month = now.getMonth() + 1;
        const year = now.getFullYear();

        const data = await this.api(`calendar.php?month=${month}&year=${year}`);

        container.innerHTML = `
            <div class="animate-fade-in">
                <div class="content-card">
                    <div class="content-card-header">
                        <div class="content-card-title"><i class="fas fa-calendar-alt"></i> Academic Calendar</div>
                        <div class="flex gap-2">
                            <button class="btn btn-ghost btn-sm"><i class="fas fa-chevron-left"></i></button>
                            <span style="font-weight: 600; min-width: 120px; text-align: center;">${now.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span>
                            <button class="btn btn-ghost btn-sm"><i class="fas fa-chevron-right"></i></button>
                        </div>
                    </div>
                    <div class="content-card-body">
                        <div class="calendar-grid">
                            ${['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => 
                                `<div class="calendar-day-header">${d}</div>`
                            ).join('')}
                            ${this.generateCalendarDays(year, month, data)}
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    generateCalendarDays(year, month, data) {
        const firstDay = new Date(year, month - 1, 1).getDay();
        const daysInMonth = new Date(year, month, 0).getDate();
        const today = new Date().getDate();
        const todayMonth = new Date().getMonth() + 1;
        const todayYear = new Date().getFullYear();

        let html = '';

        for (let i = 0; i < firstDay; i++) {
            html += '<div class="calendar-day" style="background: var(--bg-secondary);"></div>';
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const isToday = day === today && month === todayMonth && year === todayYear;
            const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

            const dayEvents = (data?.events || []).filter(e => e.event_date === dateStr);
            const dayAssignments = (data?.assignments || []).filter(a => a.due_date.startsWith(dateStr));

            html += `
                <div class="calendar-day ${isToday ? 'today' : ''}" onclick="app.showDayEvents('${dateStr}')">
                    <div class="calendar-day-number ${isToday ? 'gradient-text' : ''}">${day}</div>
                    ${dayEvents.map(e => `
                        <div class="calendar-event" style="background: ${e.color}30; color: ${e.color}; border-left: 3px solid ${e.color};">
                            ${e.title}
                        </div>
                    `).join('')}
                    ${dayAssignments.map(a => `
                        <div class="calendar-event" style="background: #ef444420; color: #ef4444; border-left: 3px solid #ef4444;">
                            <i class="fas fa-clock"></i> ${a.title}
                        </div>
                    `).join('')}
                </div>
            `;
        }

        return html;
    }

    async loadResources(container) {
        const data = await this.api('resources.php');
        if (!data || !data.success) {
            container.innerHTML = '<div class="empty-state"><div class="empty-state-title">Failed to load resources</div></div>';
            return;
        }

        const resources = data.resources || [];

        container.innerHTML = `
            <div class="animate-fade-in">
                <div class="content-card">
                    <div class="content-card-header">
                        <div class="content-card-title"><i class="fas fa-book-open"></i> Resource Library</div>
                        <div class="flex gap-2">
                            <div class="search-box">
                                <i class="fas fa-search"></i>
                                <input type="text" placeholder="Search resources..." onkeyup="app.searchResources(this.value)">
                            </div>
                            <select class="form-select" style="width: 140px;" onchange="app.filterResourcesByType(this.value)">
                                <option value="">All Types</option>
                                <option value="notes">Notes</option>
                                <option value="past_paper">Past Papers</option>
                                <option value="slides">Slides</option>
                                <option value="lab_manual">Lab Manuals</option>
                                <option value="template">Templates</option>
                            </select>
                            <button class="btn btn-primary btn-sm" onclick="app.showUploadResourceModal()">
                                <i class="fas fa-upload"></i> Upload
                            </button>
                        </div>
                    </div>
                    <div class="content-card-body">
                        ${resources.length > 0 ? `
                            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">
                                ${resources.map(r => `
                                    <div class="card" style="display: flex; flex-direction: column;">
                                        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                                            <div style="width: 48px; height: 48px; background: ${this.getResourceTypeColor(r.resource_type)}20; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; color: ${this.getResourceTypeColor(r.resource_type)}; font-size: 20px;">
                                                <i class="fas ${this.getResourceTypeIcon(r.resource_type)}"></i>
                                            </div>
                                            <div style="flex: 1; min-width: 0;">
                                                <div style="font-weight: 600; font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${r.title}</div>
                                                <div style="font-size: 12px; color: var(--text-muted);">${r.course_name || 'General'} • ${r.uploader_name}</div>
                                            </div>
                                        </div>
                                        <div style="font-size: 13px; color: var(--text-secondary); margin-bottom: 12px; flex: 1;">${r.description || 'No description'}</div>
                                        <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 12px; border-top: 1px solid var(--border-color);">
                                            <div style="display: flex; gap: 8px; align-items: center;">
                                                <span class="badge badge-primary" style="font-size: 11px;">${r.resource_type}</span>
                                                ${r.is_verified ? '<span class="badge badge-success" style="font-size: 11px;"><i class="fas fa-check-circle"></i> Verified</span>' : ''}
                                            </div>
                                            <div style="display: flex; gap: 8px;">
                                                <button class="btn btn-ghost btn-sm" onclick="app.bookmarkResource(${r.resource_id})">
                                                    <i class="fas fa-bookmark"></i>
                                                </button>
                                                <a href="${r.file_url}" class="btn btn-primary btn-sm" target="_blank">
                                                    <i class="fas fa-download"></i>
                                                </a>
                                            </div>
                                        </div>
                                        ${r.avg_rating ? `
                                            <div style="margin-top: 8px; font-size: 12px; color: var(--warning);">
                                                ${'★'.repeat(Math.round(r.avg_rating))}${'☆'.repeat(5 - Math.round(r.avg_rating))}
                                                <span style="color: var(--text-muted);">(${r.rating_count})</span>
                                            </div>
                                        ` : ''}
                                    </div>
                                `).join('')}
                            </div>
                        ` : `
                            <div class="empty-state">
                                <div class="empty-state-icon">📚</div>
                                <div class="empty-state-title">No resources found</div>
                                <div class="empty-state-text">Be the first to upload study materials!</div>
                            </div>
                        `}
                    </div>
                </div>
            </div>
        `;
    }

    async loadSchedule(container) {
        const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

        container.innerHTML = `
            <div class="animate-fade-in">
                <div class="content-card">
                    <div class="content-card-header">
                        <div class="content-card-title"><i class="fas fa-calendar-week"></i> Weekly Schedule</div>
                        <button class="btn btn-primary btn-sm">
                            <i class="fas fa-plus"></i> Add Event
                        </button>
                    </div>
                    <div class="content-card-body">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
                            ${days.map(day => `
                                <div style="background: var(--bg-secondary); border-radius: var(--radius-lg); padding: 20px;">
                                    <div style="font-size: 16px; font-weight: 700; margin-bottom: 16px; color: ${day === new Date().toLocaleDateString('en-US', {weekday: 'long'}) ? 'var(--primary-light)' : 'var(--text-primary)'};">
                                        ${day} ${day === new Date().toLocaleDateString('en-US', {weekday: 'long'}) ? '<span style="font-size: 12px; background: var(--primary); color: white; padding: 2px 8px; border-radius: 10px; margin-left: 8px;">Today</span>' : ''}
                                    </div>
                                    <div style="min-height: 100px; display: flex; align-items: center; justify-content: center; color: var(--text-muted); font-size: 14px;">
                                        <i class="fas fa-calendar-day" style="margin-right: 8px;"></i> No classes scheduled
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    getPriorityColor(priority) {
        const colors = { low: '#10b981', medium: '#f59e0b', high: '#ef4444', urgent: '#dc2626' };
        return colors[priority] || '#94a3b8';
    }

    getResourceTypeColor(type) {
        const colors = { notes: '#6366f1', past_paper: '#f59e0b', slides: '#3b82f6', lab_manual: '#10b981', template: '#8b5cf6', reference: '#06b6d4', other: '#94a3b8' };
        return colors[type] || '#94a3b8';
    }

    getResourceTypeIcon(type) {
        const icons = { notes: 'fa-sticky-note', past_paper: 'fa-file-alt', slides: 'fa-images', lab_manual: 'fa-flask', template: 'fa-file-code', reference: 'fa-book', other: 'fa-file' };
        return icons[type] || 'fa-file';
    }

    formatDate(dateString) {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    }

    getTimeLeft(dateString) {
        if (!dateString) return '';
        const due = new Date(dateString);
        const now = new Date();
        const diff = due - now;

        if (diff < 0) return '<span style="color: var(--danger);">Overdue</span>';

        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

        if (days > 0) return `${days}d ${hours}h left`;
        if (hours > 0) return `${hours}h left`;
        return '<span style="color: var(--danger);">Due soon</span>';
    }

    formatFileSize(bytes) {
        if (!bytes) return 'N/A';
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(1024));
        return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
    }

    async startNotificationPolling() {
        await this.checkNotifications();
        setInterval(() => this.checkNotifications(), 30000);
    }

    async checkNotifications() {
        const data = await this.api('notifications.php');
        if (data && data.success) {
            const badge = document.getElementById('notificationBadge');
            if (badge) {
                badge.textContent = data.unread_count;
                badge.style.display = data.unread_count > 0 ? 'block' : 'none';
            }
        }
    }

    toggleNotifications() {
        this.showToast('Notifications panel - Feature coming soon!', 'info');
    }

    showToast(message, type = 'info') {
        let container = document.querySelector('.toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'toast-container';
            document.body.appendChild(container);
        }

        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;

        const icons = {
            success: 'fa-check-circle',
            error: 'fa-times-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };

        toast.innerHTML = `
            <i class="fas ${icons[type] || icons.info}"></i>
            <span>${message}</span>
        `;

        container.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(100%)';
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }

    showCreateGroupModal() {
        this.showModal('Create Project Group', `
            <div class="form-group">
                <label class="form-label">Group Name</label>
                <input type="text" class="form-input" id="groupName" placeholder="Enter group name">
            </div>
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea class="form-textarea" id="groupDesc" placeholder="Describe your project..."></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Project Deadline</label>
                <input type="date" class="form-input" id="groupDeadline">
            </div>
        `, async () => {
            const name = document.getElementById('groupName').value;
            const desc = document.getElementById('groupDesc').value;
            const deadline = document.getElementById('groupDeadline').value;

            if (!name) {
                this.showToast('Group name is required', 'error');
                return;
            }

            const result = await this.api('projects.php', {
                method: 'POST',
                body: {
                    action: 'create_group',
                    group_name: name,
                    description: desc,
                    project_deadline: deadline
                }
            });

            if (result && result.success) {
                this.showToast('Group created successfully!', 'success');
                this.loadPage('projects');
            } else {
                this.showToast(result?.message || 'Failed to create group', 'error');
            }
        });
    }

    showAddTaskModal(groupId) {
        this.showModal('Add New Task', `
            <div class="form-group">
                <label class="form-label">Task Title</label>
                <input type="text" class="form-input" id="taskTitle" placeholder="Enter task title">
            </div>
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea class="form-textarea" id="taskDesc" placeholder="Task description..."></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Priority</label>
                <select class="form-select" id="taskPriority">
                    <option value="low">Low</option>
                    <option value="medium" selected>Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Due Date</label>
                <input type="date" class="form-input" id="taskDueDate">
            </div>
        `, async () => {
            const result = await this.api('projects.php', {
                method: 'POST',
                body: {
                    action: 'add_task',
                    group_id: groupId,
                    title: document.getElementById('taskTitle').value,
                    description: document.getElementById('taskDesc').value,
                    priority: document.getElementById('taskPriority').value,
                    due_date: document.getElementById('taskDueDate').value
                }
            });

            if (result && result.success) {
                this.showToast('Task added successfully!', 'success');
                this.loadGroupDetail(groupId);
            }
        });
    }

    async postDiscussion(groupId) {
        const input = document.getElementById('discussionInput');
        const message = input.value.trim();

        if (!message) return;

        const result = await this.api('projects.php', {
            method: 'POST',
            body: {
                action: 'add_discussion',
                group_id: groupId,
                message: message
            }
        });

        if (result && result.success) {
            input.value = '';
            this.loadGroupDetail(groupId);
            this.showToast('Message posted!', 'success');
        }
    }

    showModal(title, bodyContent, onConfirm) {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.innerHTML = `
            <div class="modal">
                <div class="modal-header">
                    <div class="modal-title">${title}</div>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    ${bodyContent}
                </div>
                <div class="modal-footer">
                    <button class="btn btn-ghost" onclick="this.closest('.modal-overlay').remove()">Cancel</button>
                    <button class="btn btn-primary" id="modalConfirmBtn">Confirm</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        document.getElementById('modalConfirmBtn').addEventListener('click', () => {
            onConfirm();
            modal.remove();
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });
    }

    async logout() {
        await this.api('auth.php', {
            method: 'POST',
            body: { action: 'logout' }
        });

        localStorage.removeItem('studysync_token');
        localStorage.removeItem('studysync_user');
        window.location.href = 'login.html';
    }

    searchResources(query) {}
    filterResourcesByType(type) {}
    filterAssignments(status) {}
    showAddAssignmentModal() { this.showToast('Feature coming soon!', 'info'); }
    showUploadResourceModal() { this.showToast('Feature coming soon!', 'info'); }
    showAddMemberModal(groupId) { this.showToast('Feature coming soon!', 'info'); }
    viewAssignment(id) { this.showToast('Feature coming soon!', 'info'); }
    bookmarkResource(id) { this.showToast('Bookmarked!', 'success'); }
    showDayEvents(date) { this.showToast(`Events for ${date} - Feature coming soon!`, 'info'); }
}

const app = new StudySyncApp();
